#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_selection import VarianceThreshold
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn import metrics
#import statsmodels.api as sm
import pandas as pd
import numpy as np
import scipy
from scipy.cluster import hierarchy as hc
import matplotlib.pyplot as plt
import math
import datetime
import forestci


# In[ ]:


def remove_highly_correlated_features(df, cutoff=0.95):
    # https://chrisalbon.com/machine_learning/feature_selection/drop_highly_correlated_features/
    # Create correlation matrix
    corr_matrix = df.corr().abs()

    # Select upper triangle of correlation matrix
    upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(np.bool))

    # Find features with correlation greater than cutoff
    to_drop = [column for column in upper.columns if any(upper[column] > cutoff)]

    # Drop features
    new_df = df.drop(to_drop, axis=1)

    return new_df


def remove_constant_features(df):
    sel = VarianceThreshold()
    sel.fit(df)
    features_keep = sel.get_support(indices=True)
    features_original = np.arange(df.columns.size)
    features_delete = np.delete(features_original, features_keep)
    df = df.drop(labels=df.columns[features_delete], axis=1)
    return df


def remove_duplicate_features(df):
    new_df = df.T.drop_duplicates().T
    return new_df


def display_summary(df):
    print(df.describe(include='all'))


def check_null_value(df):
    print(df[df.isnull().any(axis=1)])


def print_rmse(m, x_train, y_train, x_test, y_test):
    print(np.sqrt(metrics.mean_squared_error(y_train, m.predict(x_train))),
         np.sqrt(metrics.mean_squared_error(y_test, m.predict(x_test))))


def print_mean_absolute_error(m, x_train, y_train, x_test, y_test):
    print(metrics.mean_absolute_error(y_train, m.predict(x_train)),
         metrics.mean_absolute_error(y_test, m.predict(x_test)))

    
def print_median_absolute_error(m, x_train, y_train, x_test, y_test):
    print(metrics.median_absolute_error(y_train, m.predict(x_train)),
         metrics.median_absolute_error(y_test, m.predict(x_test)))
    
    
def median_absolute_percentage_error(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    result = []
    for i in range(len(y_true)):
        if y_true[i] > 0:
            result.append(np.abs((y_true[i] - y_pred[i]) / y_true[i]))
    return np.median(result) * 100


def print_median_error_percentage(m, x_train, y_train, x_test, y_test):
    print(median_absolute_percentage_error(y_train, m.predict(x_train)),
          median_absolute_percentage_error(y_test, m.predict(x_test)))
    
    
def rf_feature_importance(m, df):
    return pd.DataFrame({'cols':df.columns, 'imp':m.feature_importances_})        .sort_values('imp', ascending=False)


def plot_importance(importance):
    return importance.plot('cols', 'imp', 'barh', figsize=(12,7), legend=False)


def get_train_score(x, y_train):
    np.random.seed(1)
    m = RandomForestRegressor(n_estimators=30, min_samples_leaf=5, max_features=0.6, n_jobs=-1)
    m.fit(x, y_train)
    return m.score(x, y_train)


def feature_selection(x_train, y_train, x_test, y_test):

    # Check if there is null value
    # check_null_value(x_train)
    # check_null_value(x_test)

    np.random.seed(1)
    random_forest = RandomForestRegressor(n_estimators=40, min_samples_leaf=3, max_features=0.5, n_jobs=-1)
    random_forest.fit(x_train, y_train)

    print_median_error_percentage(random_forest, x_train, y_train, x_test, y_test)

    importance = rf_feature_importance(random_forest, x_train)
    plot_importance(importance[:30])

    important_features = importance[importance.imp > 0.005].cols
    print(len(important_features))

    print(important_features)

    x_train = x_train[important_features]
    x_test = x_test[important_features]



    np.random.seed(1)
    m = RandomForestRegressor(n_estimators=40, min_samples_leaf=3, max_features=0.5, n_jobs=-1)
    m.fit(x_train, y_train)
    x_test_1 = x_test[list(x_train)]
    print_median_error_percentage(m, x_train, y_train, x_test_1, y_test)

    print(list(x_train))


# In[ ]:


df_raw = pd.read_csv('../../data/output/sql_data/sql_perf_log_slice.csv', low_memory=False, parse_dates=["TIME"])


# In[ ]:


df_raw.shape


# In[ ]:


df_raw_cpu = df_raw[df_raw.TOTAL_CPU > 5]


# In[ ]:


df_train = df_raw_cpu[df_raw_cpu['TIME'] < pd.Timestamp(datetime.date(2019, 3, 9), tz='UTC')]
df_test = df_raw_cpu[df_raw_cpu['TIME'] >= pd.Timestamp(datetime.date(2019, 3, 9), tz='UTC')]


# In[ ]:


df_y = df_raw_cpu.loc[:, 'TOTAL_CPU']
df_x = df_raw_cpu.drop(['TIME', 'TOTAL_CPU', 'TOTAL_MEM_AVAILABLE_MBYTES'], axis=1)

y_train = df_train.loc[:, 'TOTAL_CPU']
x_train = df_train.drop(['TIME', 'TOTAL_CPU', 'TOTAL_MEM_AVAILABLE_MBYTES'], axis=1)

y_test = df_test.loc[:, 'TOTAL_CPU']
x_test = df_test.drop(['TIME', 'TOTAL_CPU', 'TOTAL_MEM_AVAILABLE_MBYTES'], axis=1)


# In[ ]:


x_train, x_valid, y_train, y_valid = train_test_split(x_train, y_train, test_size=0.3, random_state=1)


# In[ ]:


df_train.TIME.describe()


# In[ ]:


# Remove features whose variance is zero
x_train = remove_constant_features(x_train)


# In[ ]:


corr_matrix = x_train.corr().abs()
upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(np.bool))
to_drop = [column for column in upper.columns if any(upper[column] > 0.7)]


# In[ ]:


x_train = x_train.drop(to_drop, axis=1)


# In[ ]:


x_train.shape


# In[ ]:


x_valid = x_valid[list(x_train)]


# In[ ]:


x_valid.shape


# # XGBoost

# In[ ]:


import xgboost


# In[ ]:


xgb_model = xgboost.XGBRegressor(seed=42) 


# In[ ]:


xgb_model.fit(x_train, y_train)


# In[ ]:


y_valid_pred = xgb_model.predict(x_valid)

mse = metrics.mean_squared_error(y_valid, y_valid_pred)

print(np.sqrt(mse))
print(metrics.explained_variance_score(y_valid, y_valid_pred))


# In[ ]:


plt.scatter(y_valid, y_valid_pred)
plt.plot([0, 40], [0, 40], 'k--')
plt.xlabel('Reported cpu')
plt.ylabel('Predicted cpu')
plt.show()


# In[ ]:


y_test_pred = xgb_model.predict(x_test)

mse = metrics.mean_squared_error(y_test, y_test_pred)

print(np.sqrt(mse))
print(metrics.explained_variance_score(y_test, y_test_pred))


# In[ ]:


plt.scatter(y_test, y_test_pred)
plt.plot([0, 40], [0, 40], 'k--')
plt.xlabel('Reported cpu')
plt.ylabel('Predicted cpu')
plt.show()


# ## Tuning XGBoost

# In[ ]:


#for tuning parameters
parameters_for_testing = {
   'colsample_bytree':[0.4,0.6,0.8],
   'gamma':[0,0.03,0.1,0.3],
   'min_child_weight':[1.5,6,10],
   'learning_rate':[0.1,0.07, 0.02],
   'max_depth':[3,5],
   'n_estimators':[100, 500, 1000, 2000],
   'reg_alpha':[1e-5, 1e-2,  0.75],
   'reg_lambda':[1e-5, 1e-2, 0.45],
   'subsample':[0.6,0.95]  
}

                    
xgb_model = xgboost.XGBRegressor(learning_rate =0.1, n_estimators=1000, max_depth=5,
    min_child_weight=1, gamma=0, subsample=0.8, colsample_bytree=0.8, nthread=6, scale_pos_weight=1, seed=27)

gsearch1 = GridSearchCV(estimator = xgb_model, param_grid = parameters_for_testing, n_jobs=6,iid=False, verbose=10,scoring='neg_mean_squared_error')
gsearch1.fit(x_train, y_train)


# In[ ]:


print (gsearch1.cv_results_)
print('best params')
print (gsearch1.best_params_)
print('best score')
print (gsearch1.best_score_)


# In[ ]:


xgb_model_best = xgboost.XGBRegressor(learning_rate =0.02, n_estimators=2000, max_depth=5,
                                      min_child_weight=1.5, gamma=0.3, subsample=0.95,
                                      colsample_bytree=0.4, reg_alpha=0.75, reg_lambda=1e-05,
                                      nthread=6, scale_pos_weight=1, seed=27)
xgb_model_best.fit(x_train, y_train)


# In[ ]:


y_valid_pred = xgb_model_best.predict(x_valid)

mse = metrics.mean_squared_error(y_valid, y_valid_pred)

print(np.sqrt(mse))
print(metrics.explained_variance_score(y_valid, y_valid_pred))


# In[ ]:


plt.scatter(y_valid, y_valid_pred)
plt.plot([0, 40], [0, 40], 'k--')
plt.xlabel('Reported cpu')
plt.ylabel('Predicted cpu')
plt.show()


# In[ ]:


y_test_pred = xgb_model_best.predict(x_test)

mse = metrics.mean_squared_error(y_test, y_test_pred)

print(np.sqrt(mse))
print(metrics.explained_variance_score(y_test, y_test_pred))


# In[ ]:


plt.scatter(y_test, y_test_pred)
plt.plot([0, 40], [0, 40], 'k--')
plt.xlabel('Reported cpu')
plt.ylabel('Predicted cpu')
plt.show()


# In[ ]:




