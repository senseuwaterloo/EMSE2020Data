#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_selection import VarianceThreshold
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn import metrics
import statsmodels.api as sm
from statistics import mean, stdev
import pandas as pd
import numpy as np
import scipy
from scipy.cluster import hierarchy as hc
import matplotlib.pyplot as plt
import math
import datetime
from cliffsDelta import cliffsDelta


# In[ ]:


pd.options.display.max_colwidth=100


# In[ ]:


def remove_highly_correlated_features(df, cutoff=0.95):
    # https://chrisalbon.com/machine_learning/feature_selection/drop_highly_correlated_features/
    # Create correlation matrix
    corr_matrix = df.corr().abs()

    # Select upper triangle of correlation matrix
    upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(np.bool))

    # Find features with correlation greater than cutoff
    to_drop = [column for column in upper.columns if any(upper[column] > cutoff)]

    # Drop features
    new_df = df.drop(to_drop, axis=1)

    return new_df


def remove_constant_features(df):
    sel = VarianceThreshold()
    sel.fit(df)
    features_keep = sel.get_support(indices=True)
    features_original = np.arange(df.columns.size)
    features_delete = np.delete(features_original, features_keep)
    df = df.drop(labels=df.columns[features_delete], axis=1)
    return df


def remove_duplicate_features(df):
    new_df = df.T.drop_duplicates().T
    return new_df


def display_summary(df):
    print(df.describe(include='all'))


def check_null_value(df):
    print(df[df.isnull().any(axis=1)])


def print_rmse(m, x_train, y_train, x_test, y_test):
    print(np.sqrt(metrics.mean_squared_error(y_train, m.predict(x_train))),
         np.sqrt(metrics.mean_squared_error(y_test, m.predict(x_test))))


def print_mean_absolute_error(m, x_train, y_train, x_test, y_test):
    print(metrics.mean_absolute_error(y_train, m.predict(x_train)),
         metrics.mean_absolute_error(y_test, m.predict(x_test)))

    
def print_median_absolute_error(m, x_train, y_train, x_test, y_test):
    print(metrics.median_absolute_error(y_train, m.predict(x_train)),
         metrics.median_absolute_error(y_test, m.predict(x_test)))
    
    
def median_absolute_percentage_error(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    result = []
    for i in range(len(y_true)):
        if y_true[i] > 0:
            result.append(np.abs((y_true[i] - y_pred[i]) / y_true[i]))
    return np.median(result) * 100


def get_prediction_error(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    result = []
    for i in range(len(y_true)):
        if y_true[i] > 0:
            result.append(np.abs((y_true[i] - y_pred[i]) / y_true[i]) * 100)
    return result


def print_median_error_percentage(m, x_train, y_train, x_test, y_test):
    print(median_absolute_percentage_error(y_train, m.predict(x_train)),
          median_absolute_percentage_error(y_test, m.predict(x_test)))
    
    
def rf_feature_importance(m, df):
    return pd.DataFrame({'cols':df.columns, 'imp':m.feature_importances_}).sort_values('imp', ascending=False)


def plot_importance(importance):
    return importance.plot('cols', 'imp', 'barh', figsize=(12,7), legend=False)


def get_train_score(x, y_train):
    np.random.seed(1)
    m = RandomForestRegressor(n_estimators=30, min_samples_leaf=5, max_features=0.6, n_jobs=-1)
    m.fit(x, y_train)
    return m.score(x, y_train)


# In[ ]:


df_train = pd.read_csv('./v0.csv', low_memory=False, parse_dates=["TIME"])


# In[ ]:


df_test = pd.read_csv('./v1.csv', low_memory=False, parse_dates=["TIME"])


# In[ ]:


df_train.shape


# In[ ]:


df_test.shape


# In[ ]:


y_train = df_train.loc[:, 'TOTAL_CPU']
x_train = df_train.drop(['TIME', 'TOTAL_CPU'], axis=1)

y_test = df_test.loc[:, 'TOTAL_CPU']
x_test = df_test.drop(['TIME', 'TOTAL_CPU'], axis=1)


# In[ ]:


df_train.TIME.describe()


# In[ ]:


df_test.TIME.describe()


# In[ ]:


# Remove features whose variance is zero
x_train = remove_constant_features(x_train)


# In[ ]:


remove_highly_correlated_features(x_train, 0.7)


# In[ ]:


x_train.shape


# In[ ]:


x_test = x_test[list(x_train)]


# In[ ]:


x_test.shape


# # Build model

# In[ ]:


np.random.seed(1)
m = RandomForestRegressor(n_estimators=100, min_samples_leaf=3, max_features=0.5, n_jobs=-1)
m.fit(x_train, y_train)

print_median_error_percentage(m, x_train, y_train, x_test, y_test)


# In[ ]:


y_test_pred = m.predict(x_test)


# In[ ]:


forest_t, forest_p = scipy.stats.mannwhitneyu(y_test_pred, y_test)


# In[ ]:


forest_p


# In[ ]:


d = cliffsDelta(y_test_pred, y_test)


# In[ ]:


d


# ### Use forest prediction to detect whether there is performance regression

# In[ ]:


forest_preds_a = m.predict(x_test)


# In[ ]:


forest_preds_b = []
for index, row in x_test.iterrows():
    m_b = RandomForestRegressor(n_estimators=100, min_samples_leaf=3, max_features=0.5, n_jobs=-1)
    m_b.fit(x_test.drop(index), y_test.drop(index))
    forest_preds_b.append(m_b.predict([row])[0])


# In[ ]:


forest_t, forest_p = scipy.stats.mannwhitneyu(forest_preds_a, forest_preds_b)


# In[ ]:


forest_p


# In[ ]:


d = cliffsDelta(forest_preds_a, forest_preds_b)


# In[ ]:


d


# In[ ]:


error_a = get_prediction_error(y_test, forest_preds_a)
error_b = get_prediction_error(y_test, forest_preds_b)


# In[ ]:


forest_t, forest_p = scipy.stats.mannwhitneyu(error_a, error_b)


# In[ ]:


forest_p


# In[ ]:


d = cliffsDelta(error_a, error_b)


# In[ ]:


d

