#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import torch
import torchtext
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.autograd import Variable
import matplotlib.pyplot as plt
from sklearn import metrics
import pandas as pd
import numpy as np
import datetime
import random
import time


# In[ ]:


SEED = 1234
torch.manual_seed(SEED)
torch.cuda.manual_seed(SEED)
torch.backends.cudnn.deterministic = True

TEXT = torchtext.data.Field()
NUMBER = torchtext.data.Field(sequential=False, dtype=torch.float, batch_first=True, use_vocab=False)


# # Load data

# In[ ]:


def get_dataset(fix_length=100, lower=False, vectors=None):
    if vectors is not None:
        # pretrain vectors only supports all lower cases
        lower = True

    train, test = torchtext.data.TabularDataset.splits(
        path='../../data/output/log_sequence/', format='csv', skip_header=True,
        train='train_full.csv', test='test_full.csv',
        fields=[
            ('TIME', None),
            ('SEQUENCE', TEXT),
            ('AVERAGE_CPU', NUMBER)
        ])

    return train, test


# In[ ]:


# Read raw data
train_data, test_data = get_dataset()


# In[ ]:


len(train_data)


# In[ ]:


print(type(vars(train_data.examples[0])['AVERAGE_CPU']))


# In[ ]:


train_data, valid_data = train_data.split(random_state=random.seed(SEED))


# In[ ]:


print(f'Number of training examples: {len(train_data)}')
print(f'Number of validation examples: {len(valid_data)}')
print(f'Number of testing examples: {len(test_data)}')


# In[ ]:


TEXT.build_vocab(train_data, max_size=25000)


# In[ ]:


print(f"Unique tokens in TEXT vocabulary: {len(TEXT.vocab)}")


# In[ ]:


print(TEXT.vocab.freqs.most_common(20))


# In[ ]:


print(TEXT.vocab.itos[:10])


# In[ ]:


BATCH_SIZE = 64

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

train_iterator, valid_iterator, test_iterator = torchtext.data.BucketIterator.splits(
    (train_data, valid_data, test_data), 
    batch_size=BATCH_SIZE,
    sort_key=lambda x: len(x.SEQUENCE),
    sort_within_batch=False,
    device=device)


# In[ ]:


class RNN(nn.Module):
    def __init__(self, input_dim, embedding_dim, hidden_dim, output_dim):
        super().__init__()
        
        self.embedding = nn.Embedding(input_dim, embedding_dim)
        self.rnn = nn.RNN(embedding_dim, hidden_dim)
        self.fc = nn.Linear(hidden_dim, output_dim)
        
    def forward(self, text):

        #text = [sent len, batch size]
        
        embedded = self.embedding(text)
        
        #embedded = [sent len, batch size, emb dim]
        
        output, hidden = self.rnn(embedded)
        
        #output = [sent len, batch size, hid dim]
        #hidden = [1, batch size, hid dim]
        
        assert torch.equal(output[-1,:,:], hidden.squeeze(0))
        
        return self.fc(hidden.squeeze(0))


# In[ ]:


INPUT_DIM = len(TEXT.vocab)
EMBEDDING_DIM = 100
HIDDEN_DIM = 256
OUTPUT_DIM = 1

model = RNN(INPUT_DIM, EMBEDDING_DIM, HIDDEN_DIM, OUTPUT_DIM)


# In[ ]:


def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

print(f'The model has {count_parameters(model):,} trainable parameters')


# In[ ]:


optimizer = optim.SGD(model.parameters(), lr=1e-3)


# In[ ]:


criterion = nn.MSELoss()


# In[ ]:


model = model.to(device)
criterion = criterion.to(device)


# In[ ]:


def train(model, iterator, optimizer, criterion):
    epoch_loss = 0
    
    model.train()
    
    for batch in iterator:
        
        optimizer.zero_grad()
                
        predictions = model(batch.SEQUENCE).squeeze(1)
        
        loss = criterion(predictions, batch.AVERAGE_CPU)
                
        loss.backward()
        
        optimizer.step()
        
        epoch_loss += loss.item()
        
    return epoch_loss / len(iterator)


# In[ ]:


def evaluate(model, iterator, criterion):
    
    epoch_loss = 0
    
    model.eval()
    
    with torch.no_grad():
    
        for batch in iterator:

            predictions = model(batch.SEQUENCE).squeeze(1)
            
            loss = criterion(predictions, batch.AVERAGE_CPU)
            
            epoch_loss += loss.item()
        
    return epoch_loss / len(iterator)


# In[ ]:


def epoch_time(start_time, end_time):
    elapsed_time = end_time - start_time
    elapsed_mins = int(elapsed_time / 60)
    elapsed_secs = int(elapsed_time - (elapsed_mins * 60))
    return elapsed_mins, elapsed_secs


# In[ ]:


N_EPOCHS = 5

best_valid_loss = float('inf')

for epoch in range(N_EPOCHS):

    start_time = time.time()
    
    train_loss = train(model, train_iterator, optimizer, criterion)
    valid_loss = evaluate(model, valid_iterator, criterion)
    
    end_time = time.time()

    epoch_mins, epoch_secs = epoch_time(start_time, end_time)
    
    if valid_loss < best_valid_loss:
        best_valid_loss = valid_loss
        torch.save(model.state_dict(), 'tut1-model.pt')
    
    print(f'Epoch: {epoch+1:02} | Epoch Time: {epoch_mins}m {epoch_secs}s')
    print(f'\tTrain Loss: {train_loss:.3f}')
    print(f'\t Val. Loss: {valid_loss:.3f}')


# In[ ]:


model.load_state_dict(torch.load('tut1-model.pt'))

test_loss = evaluate(model, test_iterator, criterion)

print(f'Test Loss: {test_loss:.3f}')


# In[ ]:


def median_absolute_percentage_error(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    result = []
    for i in range(len(y_true)):
        if y_true[i] > 0:
            result.append(np.abs((y_true[i] - y_pred[i]) / y_true[i]))
    return np.median(result) * 100


# In[ ]:


def evaluate_median(model, iterator, criterion):
    
    epoch_loss = 0
    
    preds = []
    trues = []
    
    model.eval()
    
    with torch.no_grad():
    
        for batch in iterator:

            predictions = model(batch.SEQUENCE).squeeze(1)

            for i in predictions:
                preds.append(i.item())
            
            for i in batch.AVERAGE_CPU:
                trues.append(i.item())
            
#             epoch_loss += loss.item()
        
    return metrics.median_absolute_error(trues, preds), median_absolute_percentage_error(trues, preds)


# In[ ]:


test_loss_median, test_loss_median_percentage = evaluate_median(model, test_iterator, criterion)

print(f'Test Median Loss: {test_loss_median:.3f}, Median Loss Percentage: {test_loss_median_percentage}')


# In[ ]:




